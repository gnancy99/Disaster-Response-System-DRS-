Create database disaster_response;

use disaster_response;

CREATE TABLE users (
    user_id SERIAL PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(100) NOT NULL,
    department_id varchar(10),
    role VARCHAR(50) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE
);

CREATE TABLE disaster_reports (
    report_id SERIAL PRIMARY KEY,
    disaster_type VARCHAR(100) NOT NULL,
    severity_level VARCHAR(50) NOT NULL,
    location VARCHAR(200) NOT NULL,
    description TEXT,
    department VARCHAR(100) NOT NULL,  
    responder VARCHAR(100) NOT NULL,   
    reported_by INT REFERENCES users(user_id),
    reported_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status varchar(100),
    response_details varchar(100)
);

CREATE TABLE coordination_responses (
    response_id SERIAL PRIMARY KEY,
    report_id INT REFERENCES disaster_reports(report_id),
    response_details TEXT NOT NULL,
    response_by INT REFERENCES users(user_id),
    response_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE notifications (
    id SERIAL PRIMARY KEY,
    report_id INT NOT NULL,
    department VARCHAR(50) NOT NULL,
    message TEXT NOT NULL,
    is_read BOOLEAN DEFAULT FALSE,
    Status varchar (100)
);



-- Insert Dummy Data 
INSERT INTO users (username, password, department_id, role, full_name, email) VALUES
('fire_user', '1', 1, 'FireCoordinator', 'User 1', 'fire@system.com'),
('emergency_user', '1', 2, 'EmergencyCoordinator', 'User 2', 'emergency@system.com'),
('admin', '1', 3, 'Admin', 'Admin', 'admin@system.com');

